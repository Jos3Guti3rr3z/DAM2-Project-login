//
//  MascotaViewController.swift
//  VetCare-v1
//
//  Created by XCODE on 22/04/26.
//

import UIKit

class MascotaViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mascotas.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

                let mascota = mascotas[indexPath.row]

                cell.textLabel?.text = mascota.nombre
                cell.detailTextLabel?.text = mascota.especie

                cell.imageView?.image = mascota.imagen

                return cell
    }
    

    var mascotas: [MascotaVM] = []
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.dataSource = self
        tableView.delegate = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "irFormulario" {
                let destino = segue.destination as! FormularioMascotaViewController
                destino.delegate = self
            }
        }
}

extension MascotaViewController: FormularioMascotaDelegate {
    func agregarMascota(_ mascota: MascotaVM) {
        print("🟢 LLEGÓ MASCOTA:", mascota.nombre)
        mascotas.append(mascota)
        tableView.reloadData()
    }
}
